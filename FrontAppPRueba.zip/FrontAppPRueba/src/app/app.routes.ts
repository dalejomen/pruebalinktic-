import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MiNuevaPaginaComponent } from './pages/mi-nueva-pagina/mi-nueva-pagina.component';
import { MiInsertInventarioComponent } from './pages/mi-insert-inventario/mi-insert-inventario.component';
import { MiEliminarInventarioComponent } from './pages/mi-eliminar-inventario/mi-eliminar-inventario.component';
import { MiActualizarInventarioComponent } from './pages/mi-actualizar-inventario/mi-actualizar-inventario.component';

export const routes: Routes = [
    {path:'', component:HomeComponent},
    {path:'nueva-pagina', component: MiNuevaPaginaComponent },
    {path:'InsertInventario', component: MiInsertInventarioComponent },
    {path:'EliminarInventario', component: MiEliminarInventarioComponent },
    {path:'ActualizarInventario', component: MiActualizarInventarioComponent },
];
