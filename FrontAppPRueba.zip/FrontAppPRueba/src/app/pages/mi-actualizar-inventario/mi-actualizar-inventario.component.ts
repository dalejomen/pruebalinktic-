import { Component } from '@angular/core';

@Component({
  selector: 'app-mi-actualizar-inventario',
  standalone: true,
  imports: [],
  templateUrl: './mi-actualizar-inventario.component.html',
  styleUrl: './mi-actualizar-inventario.component.scss'
})
export class MiActualizarInventarioComponent {

}
