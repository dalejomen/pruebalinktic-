import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiEliminarInventarioComponent } from './mi-eliminar-inventario.component';

describe('MiEliminarInventarioComponent', () => {
  let component: MiEliminarInventarioComponent;
  let fixture: ComponentFixture<MiEliminarInventarioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MiEliminarInventarioComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MiEliminarInventarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
