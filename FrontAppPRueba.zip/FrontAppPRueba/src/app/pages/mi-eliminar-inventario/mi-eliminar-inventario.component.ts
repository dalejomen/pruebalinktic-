import { Component } from '@angular/core';
import { ApiService } from '../../service/api.service';
import { FormsModule }   from '@angular/forms';

@Component({
  selector: 'app-mi-eliminar-inventario',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './mi-eliminar-inventario.component.html',
  styleUrl: './mi-eliminar-inventario.component.scss'
})
export class MiEliminarInventarioComponent {
inventario = {
    inventarioID: 0
  };

   constructor(private apiService:ApiService){}
  
  eliminar() {
    this.apiService.eliminarInventario(this.inventario).subscribe({
      next: res => alert('Inventario eliminado correctamente'),
      error: err => alert('Error al insertar: ' + err.message)
    });
  }
}
