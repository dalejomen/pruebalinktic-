import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiInsertInventarioComponent } from './mi-insert-inventario.component';

describe('MiInsertInventarioComponent', () => {
  let component: MiInsertInventarioComponent;
  let fixture: ComponentFixture<MiInsertInventarioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MiInsertInventarioComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MiInsertInventarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
