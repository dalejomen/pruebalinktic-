import { Component } from '@angular/core';
import { ApiService } from '../../service/api.service';
import { FormsModule }   from '@angular/forms';

@Component({
  selector: 'app-mi-insert-inventario',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './mi-insert-inventario.component.html',
  styleUrl: './mi-insert-inventario.component.scss'
})


export class MiInsertInventarioComponent {

   inventario = {
    productoID: 0,
    cantidad: 0,
    ubicacion: ''
  };

   constructor(private apiService:ApiService){}
  
  insertar() {
    this.apiService.insertarInventario(this.inventario).subscribe({
      next: res => alert('Inventario insertado correctamente'),
      error: err => alert('Error al insertar: ' + err.message)
    });
  }
}
