import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MiNuevaPaginaComponent } from './mi-nueva-pagina.component';

describe('MiNuevaPaginaComponent', () => {
  let component: MiNuevaPaginaComponent;
  let fixture: ComponentFixture<MiNuevaPaginaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MiNuevaPaginaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MiNuevaPaginaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
