import { Component } from '@angular/core';
import { ApiService } from '../../service/api.service';

@Component({
  selector: 'app-mi-nueva-pagina',
  standalone: true,
  imports: [],
  templateUrl: './mi-nueva-pagina.component.html',
  styleUrl: './mi-nueva-pagina.component.scss'
})
export class MiNuevaPaginaComponent {

  data: any[] = [];

  constructor(private apiService:ApiService){}

  ngOnInit():void{
    this.llenarData();
  } 
  
  llenarData () {
    this.apiService.getDataProductos().subscribe(data =>{
      this.data = data;
      console.log(this.data);
    })      

  }

}
