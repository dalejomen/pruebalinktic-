import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private urlApi = 'https://localhost:44384/v1/Prueba/Entidades';
  private urlApiGetInventario = 'https://localhost:44384/v1/Inventario/GetInventario';
  private urlApiPostInventario = 'https://localhost:44384/v1/Inventario/PostInventario';
  private urlApideleteInventario = 'https://localhost:44384/v1/Inventario/DeleteInventario';  
  private urlApiGetProductos = 'https://localhost:44384/v1/Producto/GetProducto';  


  constructor(private http: HttpClient) {}
  
  public getData():Observable<any>{
    return this.http.get<any>(this.urlApi);
  }   

  public getDataInvenario():Observable<any>{
    return this.http.get<any>(this.urlApiGetInventario);
  }

  public getDataProductos():Observable<any>{
    return this.http.get<any>(this.urlApiGetProductos);
  }

  public insertarInventario(inventario: any): Observable<any> {
    return this.http.post(this.urlApiPostInventario, inventario); // El body se envía como JSON automáticamente
  }

  public eliminarInventario(inventario: any): Observable<any> {
    return this.http.delete(this.urlApideleteInventario, inventario); // El body se envía como JSON automáticamente
  }
}
