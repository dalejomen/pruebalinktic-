﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.Person.Models
{
    public class AsesorModel
    {
        public string Asesor_Principal { get; set;}
        public string Email_Asesor_Principal { get; set; }
    }
}
