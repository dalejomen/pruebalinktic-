namespace Ibero.Services.Avaya.Domain.Person.Models
{
    public class PersonModel
    {
        public string Num_Document { get; set; }

        public string Id_Banner { get; set; }

        public string Nam_Person { get; set; }

        public string Last_NamePerson { get; set; }
    }
}
