﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.Uassessment.Models
{
    public class CampusModel
    {       
        public string Id_campus { get; set; }
        public string Codigo_campus { get; set; }
        public string Nombre_campus { get; set; }
        public string Id_institucion { get; set; }
    }

   
}
