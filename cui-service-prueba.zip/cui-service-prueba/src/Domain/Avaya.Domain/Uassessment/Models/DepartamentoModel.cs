﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.Uassessment.Models
{
    public class DepartamentoModel
    {       
        public int Id { get; set; }
        public string id_departamento { get; set; }
        public string codigo_departamento { get; set; }
        public string nombre_departamento { get; set; }
        public string id_facultad { get; set; }
    }

   
}
