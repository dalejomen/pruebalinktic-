﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ibero.Services.Avaya.Domain.Uassessment.Models
{
    public class JornadaModel
    {       
        public int Id { get; set; }
        public string Id_jornada { get; set; }
        public string Codigo_jornada { get; set; }
        public string Nombre_jornada { get; set; }
    }

   
}
