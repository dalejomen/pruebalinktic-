﻿namespace Ibero.Services.Avaya.Domain.ZohoCrmDwh.Model
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Entidad
    {
        public string ID { get; set; }
        public string Nombre { get; set; }
    }
}
