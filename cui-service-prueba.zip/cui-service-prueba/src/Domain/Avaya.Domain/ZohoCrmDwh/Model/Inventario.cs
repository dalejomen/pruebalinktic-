﻿namespace Ibero.Services.Avaya.Domain.ZohoCrmDwh.Model
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Inventario
    {
        public string InventarioID { get; set; }
        public string ProductoID { get; set; }
        public string NombreProducto { get; set; }
        public string Cantidad { get; set; }
        public string Ubicacion { get; set; }
        public string FechaActualizacion { get; set; }


    }
}
