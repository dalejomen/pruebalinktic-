﻿namespace Ibero.Services.Avaya.Domain.ZohoCrmDwh.Model
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Producto
    {
        public string ProductoID { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Precio { get; set; }
        public string FechaCreacion { get; set; }

    }
}
