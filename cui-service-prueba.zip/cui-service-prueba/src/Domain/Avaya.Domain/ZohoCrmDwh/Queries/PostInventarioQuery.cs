﻿using AutoMapper;
using Ibero.Services.Avaya.Core.Entities;
using Ibero.Services.Avaya.Core.Models;
using Ibero.Services.Avaya.Domain.Exceptions;
using Ibero.Services.Avaya.Domain.Infrastructure.Abstract;
using Ibero.Services.Avaya.Domain.Infrastructure.Configuration;
using MediatR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;

namespace Ibero.Services.Avaya.Domain.ZohoCrmDwh.Queries
{
    public class PostInventarioQuery : IRequest<object>
    {
        public int ProductoID { get; set; }
        public int Cantidad { get; set; }
        public string Ubicacion { get; set; }

        public class Handler : IRequestHandler<PostInventarioQuery, object>
        {
            private readonly IAvayaDbContext context;
            private readonly IMapper mapper;
            private readonly string _connection;


            public Handler(IAvayaDbContext context, IMapper mapper, IConfiguration configuration)
            {
                this.context = context;
                this.mapper = mapper;
                _connection = configuration.GetConnectionString("DWHIbero");
            }
            public async Task<object> Handle(PostInventarioQuery request, CancellationToken cancellationToken)
            {
                var response = new object();
                var infoDB = "";

                try
                {
                    using (SqlConnection sql = new SqlConnection(_connection))
                    {
                        using (SqlCommand cmd = new SqlCommand("InsertarInventario", sql))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@ProductoID", SqlDbType.Int).Value = request.ProductoID;
                            cmd.Parameters.Add("@Cantidad", SqlDbType.Int).Value = request.Cantidad;
                            cmd.Parameters.Add("@Ubicacion", SqlDbType.VarChar).Value = request.Ubicacion;

                            await sql.OpenAsync();

                            using (var sqlReader = await cmd.ExecuteReaderAsync())
                            {
                                while (await sqlReader.ReadAsync())
                                {
                                    infoDB += sqlReader[0].ToString();
                                }
                            }
                        }
                    }
                    response = infoDB;
                }
                catch (Exception ex)
                {
                    throw new DeleteFailureException(nameof(PostInventarioQuery), ex.Message, ex.Message);
                }
                return response;
            }
        }
    }
}
