﻿using Ibero.Services.Avaya.Core.Models;
using Ibero.Services.Avaya.Domain.ZohoCrmDwh.Commands;
using Ibero.Services.Avaya.Domain.ZohoCrmDwh.Queries;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Ibero.Services.Avaya.API.V1.Controllers
{
    public class ProductoController : BaseController
    {
        // GET: ProductoController
        [HttpGet("GetProducto")]        
        public async Task<ActionResult<IEnumerable<object>>> Producto([FromRoute] ProductoQuery query)
        {
            return Ok(await Mediator.Send(query));
        }

        [HttpPost("PostProducto")]
        public async Task<ActionResult<Response>> PostProducto([FromBody] PostProductoQuery query)
        {
            try
            {                
                var status = Ok(await Mediator.Send(query));

                var response = new Response
                {
                    Title = status.Value.ToString(),
                    Message = "Success",
                    Status = status.StatusCode.ToString()
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new Response
                {
                    Title = ex.Source,
                    Message = ex.Message,
                    Status = StatusCodes.Status400BadRequest.ToString()
                };

                return response;
            }
        }

        [HttpPut("PutProducto")]
        public async Task<ActionResult<Response>> PutProducto([FromBody] PutProductoQuery query)
        {
            try
            {
                var status = Ok(await Mediator.Send(query));

                var response = new Response
                {
                    Title = status.Value.ToString(),
                    Message = "Success",
                    Status = status.StatusCode.ToString()
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new Response
                {
                    Title = ex.Source,
                    Message = ex.Message,
                    Status = StatusCodes.Status400BadRequest.ToString()
                };

                return response;
            }
        }

        [HttpDelete("DeleteProducto")]
        public async Task<ActionResult<Response>> DeleteProducto([FromBody] DeleteProductoQuery query)
        {
            try
            {
                var status = Ok(await Mediator.Send(query));

                var response = new Response
                {
                    Title = status.Value.ToString(),
                    Message = "Success",
                    Status = status.StatusCode.ToString()
                };
                return response;
            }
            catch (Exception ex)
            {
                var response = new Response
                {
                    Title = ex.Source,
                    Message = ex.Message,
                    Status = StatusCodes.Status400BadRequest.ToString()
                };

                return response;
            }
        }

    }
}
